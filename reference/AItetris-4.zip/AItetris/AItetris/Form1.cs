﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AItetris
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public class DisplayController
        {
            private PictureBox pic;
            private Bitmap bmp;
            private Graphics g;

            private System.Windows.Forms.Timer retimer;
            private Image tmpimg;

            public Size DisplaySize { get; set; }
            public int[,] Pixels { get; set; }
            public int PixelWidth { get; set; }
            public int PixelSpace { get; set; }
            public Color BackgroundColor { get; set; }
            public Color DisplayColor { get; set; }
            public Size PictureSize { get; private set; }

            public DisplayController(int[,] pixels, PictureBox pictureBox)
            {
                PixelWidth = 10;
                PixelSpace = 3;
                BackgroundColor = Color.Black;
                DisplayColor = Color.GreenYellow;

                DisplaySize = new Size(pixels.GetLength(0)-1, pixels.GetLength(1)-1);
                Pixels = pixels;
                pic = pictureBox;


            }
            private void ReTime_Tick(object sender,EventArgs e)
            {
                pic.Image = tmpimg;
            }

            public void Initialize()
            {
                pic.Location = new Point(0, 0);
                PictureSize = new Size(DisplaySize.Width * (PixelWidth + PixelSpace) + PixelSpace, DisplaySize.Height * (PixelWidth + PixelSpace) + PixelSpace);
                bmp = new Bitmap(PictureSize.Width, PictureSize.Height);
                g = Graphics.FromImage(bmp);
                pic.Size = PictureSize;

                retimer = new System.Windows.Forms.Timer();
                retimer.Tick += ReTime_Tick;
                retimer.Interval = 1;
                //retimer.Start();
            }
            public void RefreshScreen()
            {

                g.Clear(BackgroundColor);
                SolidBrush sb = new SolidBrush(DisplayColor);
                Pen pen = new Pen(DisplayColor);

                for (int x = 0; x < DisplaySize.Width; x++)
                {
                    for (int y = 0; y < DisplaySize.Height; y++)
                    {
                        if (Pixels[x+1, y+1] == 1)
                        {
                            g.FillRectangle(sb, x * (PixelWidth + PixelSpace) + PixelSpace, y * (PixelWidth + PixelSpace) + PixelSpace, PixelWidth, PixelWidth);
                        }
                        else if (Pixels[x+1, y+1] == 2)
                        {
                            g.DrawRectangle(pen, x * (PixelWidth + PixelSpace) + PixelSpace, y * (PixelWidth + PixelSpace) + PixelSpace, PixelWidth, PixelWidth);

                        }
                    }
                }
                tmpimg = new Bitmap(bmp);
                pic.Invoke(new Action(() =>
                {
                    pic.Image = tmpimg;
                }));
            }

        }





        int sleeptime = 10;
        private class node
        {
            public int x;
            public int y;
        }

        private class brick
        {
            public List<node> cores;
            public int type;

            public int mov_x;
            public int mov_y;
            //shift:mid of width
            
        }

        private List<node> GetBrick(int Bricktype)
        {
            List<node> ret = new List<node>();
            if (Bricktype == 1) 
            {
                //O
                node node1 = new node() { x = 0, y = 0 };
                ret.Add(node1);
                node node2 = new node() { x = 1, y = 0 };
                ret.Add(node2);
                node node3 = new node() { x = 1, y = -1 };
                ret.Add(node3);
                node node4 = new node() { x = 0, y = -1 };
                ret.Add(node4);
                return ret;
            }
            if (Bricktype == 2) 
            {
                //I
                node node1 = new node() { x = 0, y = 0 };
                ret.Add(node1);
                node node2 = new node() { x = -1, y = 0 };
                ret.Add(node2);
                node node3 = new node() { x = 1, y = 0 };
                ret.Add(node3);
                node node4 = new node() { x = 2, y = 0 };
                ret.Add(node4);
                return ret;
            }
            if (Bricktype == 3) 
            {
                //T
                node node1 = new node() { x = 0, y = 0 };
                ret.Add(node1);
                node node2 = new node() { x = -1, y = 0 };
                ret.Add(node2);
                node node3 = new node() { x = 0, y = -1 };
                ret.Add(node3);
                node node4 = new node() { x = 1, y = 0 };
                ret.Add(node4);
                return ret;
            }
            if(Bricktype == 4)
            {
                //Z
                node node1 = new node() { x = 0, y = 0 };
                ret.Add(node1);
                node node2 = new node() { x = -1, y = -1 };
                ret.Add(node2);
                node node3 = new node() { x = 0, y = -1 };
                ret.Add(node3);
                node node4 = new node() { x = 1, y = 0 };
                ret.Add(node4);
                return ret;
            }
            if(Bricktype == 5)
            {
                //S
                node node1 = new node() { x = 0, y = 0 };
                ret.Add(node1);
                node node2 = new node() { x = 1, y = -1 };
                ret.Add(node2);
                node node3 = new node() { x = 0, y = -1 };
                ret.Add(node3);
                node node4 = new node() { x = -1, y = 0 };
                ret.Add(node4);
                return ret;
            }
            if (Bricktype == 6)
            {
                //J
                node node1 = new node() { x = 0, y = 0 };
                ret.Add(node1);
                node node2 = new node() { x = 0, y = -1 };
                ret.Add(node2);
                node node3 = new node() { x = 0, y = 1 };
                ret.Add(node3);
                node node4 = new node() { x = -1, y = 1 };
                ret.Add(node4);
                return ret;
            }
            if(Bricktype == 7)
            {
                //L
                node node1 = new node() { x = 0, y = 0 };
                ret.Add(node1);
                node node2 = new node() { x = 0, y = -1 };
                ret.Add(node2);
                node node3 = new node() { x = 0, y = 1 };
                ret.Add(node3);
                node node4 = new node() { x = 1, y = 1 };
                ret.Add(node4);
                return ret;
            }
            else
            {
                return null;
            }
        }
        private void RotateBrick(brick bk)
        {
            if (bk.type==1)
            {
                return;
            }
            foreach (node item in bk.cores)
            {
                int tx = item.x;
                int ty = item.y;
                item.x = ty;
                item.y = -tx;
            }
            //rout: x'= x*cosn+y*sinn
            //rout: y'= -x*sinn+y*cosn
            //sin90=1 cos90=0
        }
        const int map_width = 11;
        const int map_height = 23;
        int[,] map = new int[map_width, map_height];
        
        private void init(int[,] parr)
        {
            for (int j = 1; j < map_height; j++) 
            {
                for (int i = 1; i < map_width; i++)
                {
                    Console.Write(parr[i, j]);
                }
                Console.Write("\n");
            }
        }
        private void makeprint(int[,] printmap, brick trbk)
        {
            for (int i = 0; i < map_width; i++)
            {
                for (int j = 0; j < map_height; j++)
                {
                    printmap[i, j] = map[i, j];
                }
            }
            foreach (node item in trbk.cores)
            {
                //int px = item.x + trbk.mov_x;
                //int py = item.y + trbk.mov_y;
                if (item.y + trbk.mov_y > 0 && item.y + trbk.mov_y < map_height)
                {
                    printmap[item.x + trbk.mov_x, item.y + trbk.mov_y] = 1;
                }

            }
        }
        int clearline = 0;

        int[,] printmap = new int[map_width, map_height];
        private void execute(int st_x,brick trbk)
        {
            
            trbk.mov_x = st_x;
            trbk.mov_y = 0;
            Array.Clear(printmap, 0, map_height * map_width);

            

            while (canRun(trbk) == true) 
            {
                
                makeprint(printmap, trbk);

                trbk.mov_y++;
                dc.RefreshScreen();
                Thread.Sleep(sleeptime);
            }
            makeprint(printmap, trbk);

            completeline = 0;
            for (int j = 1; j <= map_height - 1; j++)
            {
                ind_comline[completeline] = j;
                completeline++;
                for (int i = 1; i <= map_width - 1; i++)
                {
                    if (printmap[i, j] == 0)
                    {
                        completeline--;
                        break;
                    }
                }
            }




            for (int k = 0; k < completeline; k++)
            {
                clearline++;
                for (int i = ind_comline[k]; i > 0; i--)
                {
                    for (int j = 1; j < map_width; j++)
                    {
                        printmap[j, i] = printmap[j, i - 1];
                    }
                }
            }
            //init(printmap);
            this.Invoke(new Action(() => { label1.Text ="Lines Cleaned:\n"+ clearline.ToString(); }));
            dc.RefreshScreen();
            Thread.Sleep(sleeptime);
            
            for (int i = 0; i < map_width; i++)
            {
                for (int j = 0; j < map_height; j++)
                {
                    map[i, j] = printmap[i, j];
                }
            }

        }

        private bool canRun(brick mbk)
        {
            int flag = 0;
            foreach (node item in mbk.cores)
            {
                int fx = item.x + mbk.mov_x;
                int fy = item.y + mbk.mov_y;
                if ( fy <= 0 )
                {
                    return true;
                }
                if (fy + 1 >= map_height || map[fx, fy + 1] == 1)
                {
                    flag++;

                }
            }
            if (flag > 0)
            {
                //foreach (node item2 in mbk.cores)
                //{
                //    map[item2.x + mbk.mov_x, item2.y + mbk.mov_y] = 1;
                //}
                return false;

            }
            return true;
        }
        private bool canRun(brick mbk,int[,] m_try)
        {
            int flag = 0;
            foreach (node item in mbk.cores)
            {
                int fx = item.x + mbk.mov_x;
                int fy = item.y + mbk.mov_y;

                if (fy <= 0 )
                {
                    return true;
                }
                if (fy + 1 >= map_height || map[fx, fy + 1] == 1)     
                {
                    flag++;
                    
                }
            }
            if (flag > 0) 
            {
                //m_try = new int[map_width, map_height];
                for (int i = 0; i < map_width; i++)
                {
                    for (int j = 0; j < map_height; j++)
                    {
                        m_try[i, j] = map[i, j];
                    }
                }
                foreach (node item2 in mbk.cores)
                {
                    m_try[item2.x + mbk.mov_x, item2.y + mbk.mov_y] = 1;
                }
                return false;

            }
            return true;
        }

        private void RunGame()
        {
            int[,] map_try;
            bool gameover = false;
            Random ran = new Random();
            
            while (gameover == false) 
            {
                double bestins = -0x7ffffff;
                int bestst = 0;
                int rotime = 0;

                int Ranbk = ran.Next(1, 8);
                brick one_bk = new brick();
                one_bk.type = Ranbk;
                one_bk.cores = GetBrick(Ranbk);

                brick two_bk = new brick();
                two_bk.type = Ranbk;
                two_bk.cores = GetBrick(Ranbk);
                map_try =new int[map_width, map_height];
                for (int i = 1; i <= 4; i++)
                {
                    
                    RotateBrick(two_bk);
                    for (int ix = 1; ix <= map_width - 1; ix++) 
                    {
                        int overrange = 0;
                        
                        foreach (node pretest in two_bk.cores)
                        {
                            if (pretest.x + ix <= 0 || pretest.x + ix >= map_width) 
                            {
                                overrange++;
                                break;
                            }
                        }
                        if (overrange > 0)
                        {
                            continue;
                        }

                        two_bk.mov_x = ix;
                        two_bk.mov_y = 0;
                        Array.Clear(map_try, 0, map_height * map_width);
                        
                        while (canRun(two_bk,map_try) == true) 
                        {
                            two_bk.mov_y++;
                        }
                        double tbest = SeekBest(map_try,two_bk);
                        //init(map_try);
                        if (tbest > bestins) 
                        {
                            bestins = tbest;
                            bestst = ix;
                            rotime = i;
                        }
                    }
                }
                for (int i = 0; i < rotime; i++)
                {
                    RotateBrick(one_bk);
                }
                //init(map_try);
                execute(bestst, one_bk);
                
            }
        }

        int[] ind_comline = new int[23];
        int holes = 0;
        int completeline = 0;
        int bumpiness = 0;
        int aheight = 0;
        private double SeekBest(int[,] map_try,brick tbk)
        {
            //init(map_try);

            int LandingHeight = map_height - (tbk.cores[0].y + tbk.mov_y);
            int Roweliminated = 0;
            int Rowtransitions = 0;
            int Columntransitions = 0;
            int Wellsum = 0;

            int[] columnHeight = new int[map_width];
            holes = 0;
            completeline = 0;
            bumpiness = 0;
            aheight = 0;

            double a = -0.610066;
            double b = 0.760666;
            double c = -0.55663;
            double d = -0.184483;

            for (int i = 1; i < map_height; i++)
            {
                int flag0 = 1;
                for (int j = 1; j < map_width; j++)
                {
                    if (flag0 != map_try[j, i]) 
                    {
                        flag0 = map_try[j, i];
                        Rowtransitions++;
                    }
                }
                if (flag0 != 1)
                {
                    Rowtransitions++;
                }
            }
            for (int i = 1; i <= map_width - 1; i++) 
            {
                int flag0 = 1;
                for (int j = 1; j <= map_height - 1; j++) 
                {
                   
                    if (map_try[i, j] == 1) 
                    {
                        columnHeight[i] = map_height - j ;
                        int flag1 = 0;
                        for (int k = j ; k <= map_height - 1; k++) 
                        {
                            if (flag0 != map_try[i, k])
                            {
                                flag0 = map_try[i, k];
                                Columntransitions++;
                            }
                            if (map_try[i, k] == 0) 
                            {
                                if (flag1 == 0) 
                                {
                                    holes++;
                                }
                                flag1 = 1;
                            }
                            else
                            {
                                flag1 = 0;
                            }
                        }
                        if (flag0 != 1)
                        {
                            Columntransitions++;
                        }
                        break;
                    }
                }
            }

            int contribute = 0;
            for (int j = 1; j <= map_height - 1; j++) 
            {
                ind_comline[completeline] = j;
                completeline++;
                for (int i = 1; i <= map_width - 1; i++) 
                {
                    if (map_try[i, j] == 0) 
                    {
                        completeline--;
                        break;
                    }
                    foreach (node item in tbk.cores)
                    {
                        if (item.y + tbk.mov_y == j) 
                        {
                            contribute++;
                        }
                    }
                }
            }
            Roweliminated = contribute * completeline;

            List<int> wells = new List<int>();
            for (int i = 1; i < map_width; i++)
            {
                int count = 0;
                for (int j = 1; j < map_height; j++)
                {
                    if (map_try[i, j] == 1) 
                    {
                        if (count != 0) 
                        {
                            wells.Add(count);
                            count = 0;
                        }
                    }
                    int left = 1;
                    int right = 1;
                    if (i - 1 >= 1) 
                    {
                        left = map_try[i - 1, j];
                    }
                    if (i + 1 < map_width) 
                    {
                        right = map_try[i + 1, j];
                    }
                    if (map_try[i, j] == 0 && left == 1 && right == 1) 
                    {
                        count++;
                    }
                }
            }
            foreach (int itemnum in wells)
            {
                Wellsum += (1 + itemnum) * itemnum / 2;
            }

            //for (int i = 1; i < map_width - 1; i++) 
            //{
            //    bumpiness += Math.Abs(columnHeight[i] - columnHeight[i + 1]);
            //    aheight += columnHeight[i];
            //}
            //aheight += columnHeight[map_width - 1];

            double index1 = -4.500158825082766;
            double index2 = 3.4181268101392694;
            double index3 = -3.2178882868487753;
            double index4 = -9.348695305445199;
            double index5 = -7.899265427351652;
            double index6 = -3.3855972247263626;
            
            return index1 * LandingHeight + index2 * Roweliminated + index3 * Rowtransitions + index4 * Columntransitions + index5 * holes + index6 * Wellsum;
            //return a * aheight + b * completeline + c * holes + d * bumpiness;
        }
        DisplayController dc;
        private void Form1_Load(object sender, EventArgs e)
        {
            dc = new DisplayController(printmap, pictureBox1);
            dc.DisplayColor = Color.Red;
            dc.BackgroundColor = Color.White;
            dc.PixelWidth = 13;
            dc.PixelSpace = 3;
            dc.Initialize();
            Thread t = new Thread(RunGame);
            t.Start();
            //RunGame();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(0);
        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                sleeptime = Math.Abs(Convert.ToInt32(textBox1.Text));
            }
            catch (Exception ex)
            {
                sleeptime = 10;
                this.Invoke(new Action(() => { this.textBox1.Text = 10.ToString(); }));
                
                //throw;
            }
                
            
        }
        int ChangeColor = 0;
        int ColorS = 3;
        private void button2_Click(object sender, EventArgs e)
        {
            ChangeColor++;
            if (ChangeColor % ColorS == 0) 
            {
                dc.BackgroundColor = Color.Black;
                dc.DisplayColor = Color.GreenYellow;
                return;
            }
            if (ChangeColor % ColorS == 1)
            {
                dc.BackgroundColor = Color.White;
                dc.DisplayColor = Color.Red;
            }
            if (ChangeColor % ColorS == 2)
            {
                dc.BackgroundColor = Color.White;
                dc.DisplayColor = Color.FromArgb(57, 197, 187);

            }
            
        }
    }
}
